// Frontend for the MediAssist AI demo. Keep API keys on the server, never in this file.
const API_BASE = 'http://localhost:5000/api/ai';
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');
const chatMessages = document.getElementById('chatMessages');
const reportFile = document.getElementById('reportFile');
const fileSelected = document.getElementById('fileSelected');
const scanProgress = document.getElementById('scanProgress');
const reportResult = document.getElementById('reportResult');
const reportText = document.getElementById('reportText');
const toast = document.getElementById('toast');
const uploadZone = document.getElementById('uploadZone');
const chatHistory = [];
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 4200);
}

function addMessage(text, who = 'assistant') {
  const row = document.createElement('div');
  row.className = `message ${who === 'user' ? 'user-message' : 'assistant-message'}`;
  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = who === 'user' ? '●' : '✦';
  const content = document.createElement('div');
  content.className = 'message-content';
  const author = document.createElement('span');
  author.className = 'message-author';
  author.textContent = who === 'user' ? 'You' : 'MediAssist AI';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  // textContent prevents model replies from being interpreted as HTML.
  bubble.textContent = text;
  content.append(author, bubble);
  row.append(avatar, content);
  chatMessages.appendChild(row);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return row;
}

function setChatBusy(busy) {
  const button = chatForm.querySelector('button[type="submit"]');
  button.disabled = busy;
  button.querySelector('span').textContent = busy ? 'Thinking…' : 'Send';
  chatInput.disabled = busy;
}

async function sendMessage(message) {
  const cleanMessage = message.trim();
  if (!cleanMessage) return;
  addMessage(cleanMessage, 'user');
  chatInput.value = '';
  setChatBusy(true);
  const pending = addMessage('Thinking through your question…', 'assistant');
  try {
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: cleanMessage, history: chatHistory })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || data.message || `Server returned ${response.status}`);
    const reply = data.reply || data.answer || data.message || 'I could not create a response. Please try again.';
    pending.querySelector('.bubble').textContent = reply;
    chatHistory.push({ role: 'user', content: cleanMessage }, { role: 'assistant', content: reply });
    // Keep the latest turns to avoid sending an unnecessarily large history.
    if (chatHistory.length > 12) chatHistory.splice(0, chatHistory.length - 12);
    if (data.emergency) showToast('If this is an emergency, contact your local emergency service now.');
  } catch (error) {
    pending.querySelector('.bubble').textContent = 'I could not connect to the AI service. Start your backend server and check that it is running at localhost:5000. If it is already running, check the API route and CORS settings.';
    showToast('Could not reach the AI backend. Check that your server is running.');
    console.error('Chat request failed:', error);
  } finally {
    setChatBusy(false);
    chatInput.focus();
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
}

chatForm.addEventListener('submit', (event) => {
  event.preventDefault();
  sendMessage(chatInput.value);
});

document.querySelectorAll('[data-prompt]').forEach((button) => {
  button.addEventListener('click', () => sendMessage(button.dataset.prompt));
});

function showFile(file) {
  if (!file) return;
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowed.includes(file.type)) {
    reportFile.value = '';
    showToast('Please choose a PNG, JPG, or WEBP image.');
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    reportFile.value = '';
    showToast('That image is larger than 8 MB. Please choose a smaller file.');
    return;
  }
  fileSelected.hidden = false;
  fileSelected.textContent = `Selected: ${file.name}`;
  analyzeReport(file);
}

reportFile.addEventListener('change', () => showFile(reportFile.files[0]));

async function analyzeReport(file) {
  scanProgress.hidden = false;
  reportResult.hidden = true;
  const formData = new FormData();
  formData.append('report', file);
  try {
    const response = await fetch(`${API_BASE}/analyze-report`, { method: 'POST', body: formData });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || data.message || `Server returned ${response.status}`);
    const analysis = data.analysis || data.result || data.reply || data.text || 'No analysis was returned. Please try another clear image.';
    reportText.textContent = typeof analysis === 'string' ? analysis : JSON.stringify(analysis, null, 2);
    reportResult.hidden = false;
    reportResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    reportText.textContent = 'Could not analyze this image because the AI backend could not be reached or the request failed. Make sure the backend is running and that its /api/ai/analyze-report endpoint accepts a multipart image field named "report".';
    reportResult.hidden = false;
    showToast('Report scan failed. Check your backend connection.');
    console.error('Report analysis failed:', error);
  } finally {
    scanProgress.hidden = true;
  }
}

document.getElementById('clearResult').addEventListener('click', () => {
  reportResult.hidden = true;
  reportText.textContent = '';
  reportFile.value = '';
  fileSelected.hidden = true;
  fileSelected.textContent = '';
});

// Drag-and-drop upload support.
['dragenter', 'dragover'].forEach((eventName) => uploadZone.addEventListener(eventName, (event) => {
  event.preventDefault();
  uploadZone.classList.add('drag-active');
}));
['dragleave', 'drop'].forEach((eventName) => uploadZone.addEventListener(eventName, (event) => {
  event.preventDefault();
  uploadZone.classList.remove('drag-active');
}));
uploadZone.addEventListener('drop', (event) => showFile(event.dataTransfer.files[0]));

// Voice assistant: uses the browser speech-recognition feature when available.
const voiceAssistant = document.getElementById('voiceAssistant');
const voiceAssistantStatus = document.getElementById('voiceAssistantStatus');
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let isListening = false;

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = 'en-IN';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.addEventListener('start', () => {
    isListening = true;
    voiceAssistant.classList.add('listening');
    voiceAssistantStatus.textContent = 'Listening… speak now';
  });
  recognition.addEventListener('result', (event) => {
    const spokenText = event.results[0][0].transcript;
    chatInput.value = spokenText;
    document.getElementById('assistant').scrollIntoView({ behavior: 'smooth', block: 'start' });
    sendMessage(spokenText);
  });
  recognition.addEventListener('error', (event) => {
    if (event.error === 'not-allowed') showToast('Please allow microphone access in your browser to use voice chat.');
    else if (event.error !== 'no-speech' && event.error !== 'aborted') showToast('Voice input stopped. Please try again.');
  });
  recognition.addEventListener('end', () => {
    isListening = false;
    voiceAssistant.classList.remove('listening');
    voiceAssistantStatus.textContent = 'Tap to speak';
  });
}

voiceAssistant.addEventListener('click', () => {
  document.getElementById('assistant').scrollIntoView({ behavior: 'smooth', block: 'start' });
  if (!recognition) {
    chatInput.focus();
    showToast('Voice input is not supported in this browser. You can type your question in the chat.');
    return;
  }
  try {
    if (isListening) recognition.stop();
    else recognition.start();
  } catch (error) {
    showToast('Voice input is already starting. Please try again in a moment.');
  }
});

const menuButton = document.getElementById('menuButton');
const sidebar = document.getElementById('sidebar');
menuButton.addEventListener('click', () => sidebar.classList.toggle('open'));
document.querySelectorAll('.sidebar .nav-link').forEach((link) => link.addEventListener('click', () => sidebar.classList.remove('open')));


// Reference-inspired homepage interactions. These forms are demo-only and do not send data to providers.
const testSearchForm = document.getElementById('testSearchForm');
const testSearch = document.getElementById('testSearch');
if (testSearchForm) testSearchForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const query = (testSearch.value || '').trim().toLowerCase();
  if (!query) { showToast('Enter a test, doctor, or specialty to search.'); return; }
  const match = [...document.querySelectorAll('.hospital-card')].find(card => card.textContent.toLowerCase().includes(query));
  if (match) { match.scrollIntoView({ behavior: 'smooth', block: 'center' }); match.classList.add('search-highlight'); setTimeout(() => match.classList.remove('search-highlight'), 1800); }
  else if (/report|scan|lab|blood|test/.test(query)) { document.getElementById('scanner')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); showToast('You can review a report image in the Medical Report Scanner.'); }
  else { document.getElementById('appointments')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); showToast('Browse the sample doctor and hospital listings below.'); }
});
const callbackForm = document.getElementById('callbackForm');
if (callbackForm) callbackForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const feedback = document.getElementById('callbackFeedback');
  feedback.hidden = false;
  feedback.textContent = 'Demo request prepared. No call has been placed and no details were sent. Connect a secure backend to enable real callbacks.';
  showToast('Demo callback request prepared. No information was sent.');
  callbackForm.reset();
});

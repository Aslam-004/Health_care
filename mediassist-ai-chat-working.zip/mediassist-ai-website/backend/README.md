# MediAssist backend (Windows-friendly)

This backend uses a local JSON file for demo persistence instead of `better-sqlite3`.
This avoids compiling native SQLite modules and the Visual Studio C++ Build Tools issue on Windows.

## Requirements
- Node.js 20+ (Node.js LTS recommended)
- VS Code

## Run
1. Open the extracted `mediassist-ai-website` folder in VS Code.
2. Open Terminal → New Terminal.
3. Run:
   ```powershell
   cd backend
   npm.cmd install
   ```
4. Copy `.env.example` to `.env` and set a private `JWT_SECRET` with at least 32 characters.
5. Add your OpenAI API key to `backend/.env` as `OPENAI_API_KEY=...` (keep it private). Optional: set `OPENAI_MODEL` (default `gpt-4o-mini`). The chat endpoint uses the OpenAI API and may require API billing/credits.
6. Start:
   ```powershell
   npm.cmd start
   ```
7. Open http://localhost:5000 in Brave.

The backend creates `mediassist-data.json` automatically. Keep it private; it contains demo account data and password hashes.

## Notes
This is a college-project demo, not production-ready or suitable for real patient data. AI chat requires an OpenAI API key configured in `backend/.env`. Report analysis is still not configured. Do not use real patient data.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 5000);
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET in backend/.env (at least 32 characters).');
  process.exit(1);
}

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Lightweight JSON storage avoids native SQLite compilation on Windows/Node versions.
const DATA_FILE = path.join(__dirname, 'mediassist-data.json');
function readData() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return {
      users: Array.isArray(data.users) ? data.users : [],
      appointments: Array.isArray(data.appointments) ? data.appointments : [],
      nextUserId: Number(data.nextUserId) || 1,
      nextAppointmentId: Number(data.nextAppointmentId) || 1
    };
  } catch {
    return { users: [], appointments: [], nextUserId: 1, nextAppointmentId: 1 };
  }
}
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}
function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\\s+/i, '');
  try {
    if (!token) throw new Error();
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Please sign in again.' });
  }
}
function role(...roles) {
  return (req, res, next) => roles.includes(req.user.role)
    ? next()
    : res.status(403).json({ error: 'Your account does not have permission for this action.' });
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'MediAssist backend' }));

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, role: accountRole } = req.body || {};
    const cleanName = String(name || '').trim();
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanPassword = String(password || '');
    if (!cleanName || !/^\\S+@\\S+\\.\\S+$/.test(cleanEmail) || cleanPassword.length < 8 ||
        !['patient', 'doctor'].includes(accountRole)) {
      return res.status(400).json({ error: 'Provide name, valid email, password (8+ characters), and patient or doctor role.' });
    }
    const data = readData();
    if (data.users.some(u => u.email === cleanEmail)) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }
    const user = {
      id: data.nextUserId++,
      name: cleanName,
      email: cleanEmail,
      password_hash: await bcrypt.hash(cleanPassword, 10),
      role: accountRole,
      created_at: new Date().toISOString()
    };
    data.users.push(user);
    writeData(data);
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
    res.status(201).json({ token, user: publicUser(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not create account.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const expectedRole = req.body?.role;
  const data = readData();
  const user = data.users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.password_hash)) ||
      (expectedRole && user.role !== expectedRole)) {
    return res.status(401).json({ error: 'Email, password, or selected portal is incorrect.' });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, user: publicUser(user) });
});

app.get('/api/auth/me', auth, (req, res) => {
  const user = readData().users.find(u => u.id === req.user.id);
  if (!user) return res.status(401).json({ error: 'Account not found.' });
  res.json({ user: publicUser(user) });
});

app.post('/api/appointments', auth, role('patient'), (req, res) => {
  const { patientName, patientContact, hospital, doctor, appointmentDate, visitType } = req.body || {};
  if (!patientName || !patientContact || !hospital || !doctor || !appointmentDate || !visitType) {
    return res.status(400).json({ error: 'Complete all appointment fields.' });
  }
  const data = readData();
  const appointment = {
    id: data.nextAppointmentId++,
    patient_id: req.user.id,
    patient_name: patientName,
    patient_contact: patientContact,
    hospital, doctor, appointment_date: appointmentDate, visit_type: visitType,
    status: 'Pending',
    created_at: new Date().toISOString()
  };
  data.appointments.push(appointment);
  writeData(data);
  res.status(201).json({ appointment: { id: appointment.id, status: appointment.status } });
});

app.get('/api/appointments', auth, (req, res) => {
  const data = readData();
  const rows = req.user.role === 'doctor'
    ? data.appointments.filter(a => !req.query.doctor || a.doctor.toLowerCase().includes(String(req.query.doctor).toLowerCase()))
    : data.appointments.filter(a => a.patient_id === req.user.id);
  const appointments = rows.sort((a, b) => a.appointment_date.localeCompare(b.appointment_date))
    .map(({ id, patient_name, hospital, doctor, appointment_date, visit_type, status, created_at }) =>
      ({ id, patient_name, hospital, doctor, appointment_date, visit_type, status, created_at }));
  res.json({ appointments });
});

app.patch('/api/appointments/:id/status', auth, role('doctor'), (req, res) => {
  const status = req.body?.status;
  if (!['Confirmed', 'Declined', 'Completed'].includes(status)) {
    return res.status(400).json({ error: 'Invalid appointment status.' });
  }
  const data = readData();
  const appointment = data.appointments.find(a => a.id === Number(req.params.id));
  if (!appointment) return res.status(404).json({ error: 'Appointment not found.' });
  appointment.status = status;
  writeData(data);
  res.json({ ok: true });
});

// AI chat uses OpenAI's server-side API. Keep OPENAI_API_KEY in backend/.env;
// never expose it in frontend JavaScript.
app.post('/api/ai/chat', async (req, res) => {
  const apiKey = String(process.env.OPENAI_API_KEY || '').trim();
  if (!apiKey) {
    return res.status(503).json({ error: 'AI is not configured. Add OPENAI_API_KEY to backend/.env, then restart the backend.' });
  }

  const message = String(req.body?.message || '').trim();
  if (!message) return res.status(400).json({ error: 'Enter a message first.' });
  if (message.length > 4000) return res.status(400).json({ error: 'Please keep your message under 4,000 characters.' });

  // Accept only recent user/assistant turns, with limits to prevent oversized requests.
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
  const messages = [
    { role: 'system', content: 'You are MediAssist, a helpful health-information assistant for an educational demo. Give clear, cautious general health information. Do not diagnose, prescribe medicines, or claim to replace a clinician. For emergencies, tell the user to contact local emergency services. Encourage users not to share identifying or sensitive medical information.' },
    ...history.filter(item => item && ['user', 'assistant'].includes(item.role) && typeof item.content === 'string')
      .map(item => ({ role: item.role, content: item.content.slice(0, 4000) })),
    { role: 'user', content: message }
  ];

  try {
    const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages, temperature: 0.4, max_tokens: 700 })
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('OpenAI API error:', upstream.status, result?.error?.message || 'Unknown error');
      if (upstream.status === 401) return res.status(502).json({ error: 'The OpenAI API key was rejected. Check OPENAI_API_KEY in backend/.env.' });
      if (upstream.status === 429) return res.status(502).json({ error: 'The AI provider rate limit or usage limit was reached. Check your API account and try again.' });
      return res.status(502).json({ error: 'The AI provider could not complete this request. Check the backend terminal for details.' });
    }
    const reply = result?.choices?.[0]?.message?.content?.trim();
    if (!reply) return res.status(502).json({ error: 'The AI provider returned an empty response. Please try again.' });
    res.json({ reply });
  } catch (error) {
    console.error('AI chat request failed:', error.message);
    res.status(502).json({ error: 'Could not reach the AI provider. Check your internet connection and try again.' });
  }
});

// Report scanning requires a vision-capable provider flow and is not enabled here.
app.post('/api/ai/analyze-report', (req, res) => res.status(503).json({ error: 'Report analysis is not configured in this demo yet.' }));

app.use(express.static(path.resolve(__dirname, '..')));
app.listen(PORT, () => console.log(`MediAssist backend running at http://localhost:${PORT}`));

/* Front-end role demo only. Enforce real permissions in backend APIs. */
(() => {
  const gate = document.getElementById('roleGate');
  if (!gate) return;
  const badge = document.getElementById('currentRoleBadge');
  const switchButton = document.getElementById('switchRoleButton');
  const navLinks = [...document.querySelectorAll('.sidebar .nav-link')];
  const roleTabs = [...document.querySelectorAll('.role-tab')];
  const note = document.getElementById('doctorPortalNote');
  const patientArea = document.getElementById('patientBookingArea');
  const adminDashboard = document.getElementById('adminDashboard');
  const appointmentSection = document.querySelector('.appointments-section');
  const patientOnlySections = ['.reference-nav', '.lab-hero', '.trust-strip', '.welcome-section', '.feature-grid'];
  let role = '', creatorMode = 'admin';

  function doctorWorkspaceMarkup() {
    return `<div class="portal-admin-card doctor-workspace-card"><div class="admin-card-heading"><span class="admin-card-icon doctor-icon">＋</span><div><strong>Doctor workspace preview</strong><p>This preview is separate from the patient portal. Doctors can manage their professional profile and availability after secure sign-in.</p></div></div><div class="booking-fields doctor-profile-fields"><label>Professional display name<input id="doctorDisplayName" value="Doctor" maxlength="80"></label><label>Availability<select id="doctorAvailability"><option>Available</option><option>Busy</option><option>On leave</option></select></label></div><button class="book-button" id="saveDoctorProfile" type="button">Save profile changes <span>→</span></button><p class="booking-feedback" id="doctorSaveFeedback" role="status" hidden></p><div class="doctor-metrics"><div><span>Total patients treated</span><strong>128 <small>demo</small></strong></div><div><span>Attendance</span><strong>Present</strong></div><div><span>Achievements</span><strong>3 <small>demo</small></strong></div></div></div>`;
  }

  function bindAdminControls() {
    document.getElementById('savePortalAnnouncement')?.addEventListener('click', () => {
      const input = document.getElementById('portalAnnouncement');
      const feedback = document.getElementById('creatorSaveFeedback');
      try { localStorage.setItem('mediassistAnnouncement', input.value); } catch {}
      if (feedback) { feedback.hidden = false; feedback.textContent = 'Announcement saved in this browser demo. Connect an administrator API to publish it for all users.'; }
    });
    document.getElementById('availabilityForm')?.addEventListener('submit', event => {
      event.preventDefault();
      const doctor = document.getElementById('availabilityDoctor').value;
      const hospital = document.getElementById('availabilityHospital').value;
      const day = document.getElementById('availabilityDay').value;
      const start = document.getElementById('availabilityStart').value;
      const end = document.getElementById('availabilityEnd').value;
      const feedback = document.getElementById('availabilityFeedback');
      if (start >= end) { feedback.hidden = false; feedback.textContent = 'End time must be later than start time.'; return; }
      const item = `${doctor} · ${hospital} · ${day}, ${start}–${end} · ${document.getElementById('availabilitySlot').value}-minute slots`;
      const list = document.getElementById('savedAvailability');
      const row = document.createElement('div'); row.className = 'saved-availability-item'; row.textContent = item; list.prepend(row);
      try { const all = JSON.parse(localStorage.getItem('mediassistAvailability') || '[]'); all.unshift(item); localStorage.setItem('mediassistAvailability', JSON.stringify(all)); } catch {}
      feedback.hidden = false; feedback.textContent = 'Availability saved in this browser demo.';
    });
    document.querySelectorAll('.admin-appointment').forEach(card => {
      card.querySelector('.admin-confirm')?.addEventListener('click', () => updateAppointment(card, 'Confirmed'));
      card.querySelector('.admin-decline')?.addEventListener('click', () => updateAppointment(card, 'Declined'));
    });
  }
  function updateAppointment(card, status) {
    card.dataset.status = status;
    const badge = card.querySelector('.appointment-status');
    badge.textContent = status; badge.className = 'appointment-status ' + (status === 'Confirmed' ? 'confirmed-status' : status === 'Declined' ? 'declined-status' : 'pending-status');
    const confirm = card.querySelector('.admin-confirm');
    if (confirm) { confirm.textContent = status === 'Confirmed' ? 'Confirmed' : 'Confirm'; confirm.disabled = status === 'Confirmed'; }
    const pending = [...document.querySelectorAll('.admin-appointment')].filter(x => x.dataset.status === 'Pending').length;
    const confirmed = [...document.querySelectorAll('.admin-appointment')].filter(x => x.dataset.status === 'Confirmed').length;
    document.getElementById('adminPending').textContent = pending;
    document.getElementById('adminConfirmed').textContent = confirmed;
  }

  function setCreatorMode(mode) {
    creatorMode = mode;
    roleTabs.forEach(tab => {
      const active = tab.dataset.role === mode;
      tab.classList.toggle('active', active); tab.setAttribute('aria-pressed', String(active));
    });
    if (adminDashboard) adminDashboard.hidden = mode !== 'admin';
    if (patientArea) patientArea.hidden = true;
    if (note) { note.hidden = mode !== 'doctor'; note.innerHTML = mode === 'doctor' ? doctorWorkspaceMarkup() : ''; }
    if (appointmentSection) {
      const title = appointmentSection.querySelector('.section-intro h2');
      const intro = appointmentSection.querySelector('.section-intro p');
      const count = appointmentSection.querySelector('.appointment-count');
      if (title) title.textContent = mode === 'admin' ? 'Administrator dashboard' : 'Doctor portal preview';
      if (intro) intro.textContent = mode === 'admin' ? 'Manage appointment confirmations and doctor availability.' : 'Doctor workspace preview. Patient-facing booking details are hidden.';
      if (count) count.hidden = true;
    }
    bindAdminControls();
    document.getElementById('saveDoctorProfile')?.addEventListener('click', () => {
      const feedback = document.getElementById('doctorSaveFeedback');
      feedback.hidden = false; feedback.textContent = 'Demo only: connect secure doctor APIs to save these changes.';
    });
  }

  function applyRoleVisibility() {
    const patient = role === 'patient';
    ['assistant', 'scanner'].forEach(id => {
      const panel = document.getElementById(id); if (panel) panel.hidden = !patient;
      const link = navLinks.find(a => a.getAttribute('href') === '#' + id); if (link) link.hidden = !patient;
    });
    document.querySelectorAll('.assistant-feature, .scanner-feature').forEach(card => card.hidden = !patient);
    const voiceButton = document.getElementById('voiceAssistant'); if (voiceButton) voiceButton.hidden = !patient;
    patientOnlySections.forEach(selector => document.querySelectorAll(selector).forEach(el => el.hidden = !patient));
    if (appointmentSection) appointmentSection.hidden = false;
  }

  function renderRole(nextRole) {
    role = nextRole; gate.hidden = true;
    if (badge) badge.textContent = role === 'creator' ? 'Administrator' : role === 'doctor' ? 'Doctor' : 'Patient';
    document.body.dataset.userRole = role;
    document.body.dataset.portalMode = role;
    roleTabs.forEach(tab => { tab.hidden = role !== 'creator'; tab.disabled = role !== 'creator'; });
    navLinks.forEach(link => { const key = link.getAttribute('href').slice(1); link.hidden = role === 'doctor' ? key !== 'appointments' : role === 'creator' ? key !== 'appointments' : false; });
    applyRoleVisibility();
    if (role === 'creator') setCreatorMode('admin');
    else if (role === 'doctor') {
      if (patientArea) patientArea.hidden = true;
      if (adminDashboard) adminDashboard.hidden = true;
      if (note) { note.hidden = false; note.innerHTML = doctorWorkspaceMarkup(); }
      if (appointmentSection) {
        appointmentSection.querySelector('.section-intro h2').textContent = 'Doctor dashboard';
        appointmentSection.querySelector('.section-intro p').textContent = 'Your professional workspace. Patient portal details are not shown here.';
      }
      document.getElementById('saveDoctorProfile')?.addEventListener('click', () => { const f = document.getElementById('doctorSaveFeedback'); f.hidden = false; f.textContent = 'Demo only: connect secure doctor APIs to save changes.'; });
    } else {
      if (patientArea) patientArea.hidden = false;
      if (adminDashboard) adminDashboard.hidden = true;
      if (note) note.hidden = true;
    }
    const target = role === 'patient' ? 'home' : 'appointments';
    const link = navLinks.find(a => a.getAttribute('href') === '#' + target); link?.click();
  }
  gate.querySelectorAll('[data-login-role]').forEach(button => button.addEventListener('click', () => renderRole(button.dataset.loginRole)));
  roleTabs.forEach(tab => tab.addEventListener('click', () => { if (role === 'creator') setCreatorMode(tab.dataset.role); }));
  switchButton?.addEventListener('click', () => { role = ''; document.body.dataset.userRole = ''; document.body.dataset.portalMode = ''; gate.hidden = false; });
  navLinks.forEach(link => link.addEventListener('click', event => {
    if (!role) { event.preventDefault(); gate.hidden = false; }
    if (role !== 'patient' && ['#assistant', '#scanner'].includes(link.getAttribute('href'))) { event.preventDefault(); event.stopImmediatePropagation(); }
    if (role === 'doctor' && link.getAttribute('href') !== '#appointments') { event.preventDefault(); event.stopImmediatePropagation(); }
  }, true));
})();

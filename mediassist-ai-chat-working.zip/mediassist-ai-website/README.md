# MediAssist AI Website

A responsive healthcare-themed frontend for a college project. It includes an AI health chat interface and an image-based lab report scanner UI.

## Files
- `index.html` — page structure
- `style.css` — responsive styling
- `app.js` — connects the UI to the AI backend

## Run it in VS Code
1. Extract the project folder and open it in VS Code.
2. Install the **Live Server** extension, if needed.
3. Right-click `index.html` and choose **Open with Live Server**.
4. Start your Node/Express AI backend in a separate terminal. This frontend expects it at `http://localhost:5000`.

## Backend API expected

### Chat
`POST http://localhost:5000/api/ai/chat`

JSON request:
```json
{
  "message": "What is a CBC test?",
  "history": []
}
```

Expected response:
```json
{
  "success": true,
  "reply": "A complete blood count ...",
  "emergency": false
}
```

### Report scanner
`POST http://localhost:5000/api/ai/analyze-report`

Multipart form-data field: `report` (PNG, JPG, or WEBP image; max 8 MB).

Expected response:
```json
{
  "success": true,
  "analysis": "Readable values and a plain-language explanation..."
}
```

The backend must enable CORS for the Live Server origin. If your backend uses a different port, change `API_BASE` at the top of `app.js`.

## Important safety notes
- Never put your OpenAI/API secret key in frontend JavaScript. Keep it in the backend `.env` file.
- This is an educational project, not a clinical tool. Do not use it to diagnose, prescribe medicines, or make treatment decisions. Users should verify extracted values against the original report and consult a qualified healthcare professional.
- Avoid uploading identifiable patient data unless you have permission and have reviewed the privacy requirements for your project.

## Role-based portal demo
The site now has a role selection screen for Patient, Doctor, and Website Creator.
- Patient: patient-facing health tools and appointment requests; no doctor portal switch.
- Doctor: doctor workspace only, with demo profile/availability controls.
- Website creator: can preview all areas and edit a demo patient-facing announcement.

**Security warning:** This is only a front-end demonstration and is not secure authentication. Since static HTML/JavaScript can be edited or bypassed in a browser, do not store real patient information or use this to authorize real access. Before deployment, implement server-side authentication (hashed passwords, secure sessions/cookies), role-based authorization on every API endpoint, database permissions, doctor-to-patient assignment checks, audit logs, and creator/admin-only configuration endpoints. Never trust a role value sent by the browser.


## Patient and doctor status login (demo)
Open `portal-login.html` directly or use the Patient / Doctor Login link in the main navigation. This is a front-end demonstration with sample statuses and no real authentication or shared hospital database. Do not enter real patient data.
